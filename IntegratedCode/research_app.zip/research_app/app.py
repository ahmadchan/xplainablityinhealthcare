from flask import Flask, render_template, request
import scispacy
import spacy
import en_core_sci_sm

def fetchEntity(unstructuredText="no input"):
  if unstructuredText=="no input":
    print("No text was passed as input. You need to pass patient related text during function call.")
  else:
    nlp_sm = en_core_sci_sm.load()
    doc = nlp_sm(unstructuredText)
    entityList=list(doc.ents)
    #print("entityList is as follows: \n", entityList)
    return entityList

app = Flask(__name__)

@app.route("/")
def home():
    return render_template('index.html')

@app.route("/about", methods= ['GET', 'POST'])
def about():
    return render_template('about.html')
   
@app.route("/structured",methods= ['GET', 'POST'])
def struc():
    if request.method == 'POST':
        parent = request.form.get('newElementId')
        print(parent.children.text)
        return render_template('index.html')# I will change this to give an error because the person has not entered words/terms, but for now I just let it reroute to index.
    elif request.method == 'GET':
        return render_template('structured.html')    

@app.route("/unstructured",methods= ['GET', 'POST'])
def unstruc():
    if request.method == "GET":
        return render_template('unstructured.html')
    if request.method == "POST": 
        userInput = request.form.get('notes')
        extracted = fetchEntity(userInput)
        return render_template('index.html', extracted = extracted) # After we have a new webpage that we want to route to (for displaying the graph, presumably)
    # we can replace index.html with that. The second part will allow us to use the extracted entities in the future webpage. 
