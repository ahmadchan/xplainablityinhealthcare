# research_app





       <div class = "container">
        <form action="#" method="POST">
            <div class = "button">
                <input type ="submit" value="Submit" class="btn btn-success" />
            </div>
        </form>      
    </div>



    {% extends 'index.html' %}
{% block content %}
  <!-- hero section markup -->

  <section class="hero">
    <div class="container">
      <div class="mid">
        <div class="desc">
            <h1> STRUCTURED DATA </h1>
            <div id="newElementId">
          <form method = "post">
            <label for="medterms">Enter medical terms:</label><br>
            <input type="text" id="fname" name="fname" value="{{ request.form['fname'] }}"><br><br>
            <input type="submit" value="Submit">
          </form>
            </div>
    </div>
    </div>
    </div>
    </section>

{% endblock content %}


            <script type="text/JavaScript">
              function addMore() {
                  // First create a DIV element.
                  var txtNewInputBox = document.createElement('input');
              
                  // Then add the content (a new input box) of the element.
                  txtNewInputBox.innerHTML = "<input type='text' id='newInputBox'>";
              
                  // Finally put it where it is supposed to appear.
                  document.getElementById("term").appendChild(txtNewInputBox);
              }
              </script>


                        <div id="dynamicCheck">
              <input type="button" value="Add" onclick="addMore();"/>
           </div>



            <script type="text/JavaScript"> // I can make it work in the sense that the ifrst text box is accessible the rest are not. 
                  function addBox() {
                      var dform = document.getElementById("dform");
                      // First create a DIV element.
                      var newText = document.createElement('input');
                  
                      // Then add the content (a new input box) of the element.
                      newText.setAttribute = ("id", "termAdd")
                      newText.setAttribute = ("type", "text")
                      newText.setAttribute = ("value", "request.form["termAdd"]")

                      document.getElementById("dform").appendChild(newText)
                      // Finally put it where it is supposed to appear.
                      // document.getElementById("dform").appendChild(newText);
                  }
                </script>